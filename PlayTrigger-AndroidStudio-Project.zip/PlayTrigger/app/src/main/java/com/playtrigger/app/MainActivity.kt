package com.playtrigger.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import java.util.Locale

private val Bg = Color(0xFF070B12)
private val Panel = Color(0xFF101925)
private val Cyan = Color(0xFF00E5FF)
private val Muted = Color(0xFF91A4B7)

class MainActivity : ComponentActivity() {
    private var webView: WebView? = null
    private var screenOff = false
    private var playbackState by mutableStateOf("READY")
    private var videoLoaded by mutableStateOf(false)
    private var pendingVideoId: String? = null
    private var pageReady = false

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    screenOff = true
                    forcePause("SCREEN OFF")
                }
                Intent.ACTION_SCREEN_ON -> {
                    screenOff = false
                    forcePause("PAUSED")
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        ContextCompat.registerReceiver(this, screenReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        setContent { PlayTriggerScreen() }
    }

    private fun forcePause(status: String) {
        webView?.post {
            webView?.evaluateJavascript("pauseVideo();", null)
            webView?.onPause()
        }
        playbackState = status
    }

    override fun onPause() {
        // Fail closed: pause before Android backgrounds this Activity.
        webView?.evaluateJavascript("pauseVideo();", null)
        webView?.onPause()
        if (!screenOff) playbackState = "PAUSED"
        super.onPause()
    }

    override fun onStop() {
        webView?.evaluateJavascript("pauseVideo();", null)
        webView?.onPause()
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        webView?.onResume()
        webView?.evaluateJavascript("pauseVideo();", null)
        // Deliberately do not resume playback here.
        if (!screenOff && playbackState == "PLAYING") playbackState = "PAUSED"
    }

    override fun onDestroy() {
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
        webView?.apply {
            evaluateJavascript("stopVideo();", null)
            removeJavascriptInterface("PlayTriggerBridge")
            stopLoading()
            loadUrl("about:blank")
            clearHistory()
            removeAllViews()
            destroy()
        }
        webView = null
        super.onDestroy()
    }

    @Composable
    private fun PlayTriggerScreen() {
        var url by remember { mutableStateOf("") }
        var error by remember { mutableStateOf("") }
        val activity = this

        MaterialTheme(colorScheme = darkColorScheme(
            primary = Cyan, background = Bg, surface = Panel,
            onPrimary = Bg, onBackground = Color.White, onSurface = Color.White
        )) {
            Column(
                modifier = Modifier.fillMaxSize().background(Bg).padding(horizontal = 18.dp, vertical = 16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).background(Cyan, RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                        Text("▶", color = Bg, fontSize = 23.sp, fontWeight = FontWeight.Black)
                    }
                    Spacer(Modifier.width(11.dp))
                    Column {
                        Text("PLAYTRIGGER", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
                        Text("PLAY ONLY WHEN YOU SAY SO", color = Cyan, fontSize = 9.sp, letterSpacing = 1.2.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    StatusPill(playbackState)
                }

                Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("VIDEO SOURCE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    OutlinedTextField(
                        value = url, onValueChange = { url = it; error = "" },
                        modifier = Modifier.fillMaxWidth(), singleLine = true,
                        placeholder = { Text("Paste YouTube video URL", color = Muted) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Cyan, unfocusedBorderColor = Color(0xFF344354), focusedTextColor = Color.White, unfocusedTextColor = Color.White)
                    )
                    Button(onClick = {
                        val id = extractVideoId(url)
                        if (id == null) error = "Enter a valid YouTube video URL or youtu.be link."
                        else {
                            error = ""
                            activity.loadVideo(id)
                        }
                    }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg), shape = RoundedCornerShape(12.dp)) {
                        Text("LOAD VIDEO", fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
                    }
                    if (error.isNotBlank()) Text(error, color = Color(0xFFFF7777), fontSize = 12.sp)
                }

                Column(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF03060A), RoundedCornerShape(18.dp)).padding(5.dp)) {
                    if (!videoLoaded) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("▶", color = Cyan, fontSize = 38.sp)
                                Text("YOUR VIDEO APPEARS HERE", color = Muted, fontSize = 11.sp, letterSpacing = 1.sp)
                                Text("Load a YouTube URL to begin", color = Muted, fontSize = 10.sp)
                            }
                        }
                    } else {
                        AndroidView(
                            modifier = Modifier.fillMaxSize(),
                            factory = { ctx -> createPlayerWebView(ctx).also { webView = it } },
                            update = { if (webView !== it) webView = it }
                        )
                    }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Button(onClick = {
                        if (videoLoaded && !screenOff) {
                            webView?.onResume()
                            webView?.evaluateJavascript("playVideo();", null)
                            playbackState = "PLAYING"
                        }
                    }, enabled = videoLoaded && !screenOff, modifier = Modifier.weight(1.35f).height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg, disabledContainerColor = Color(0xFF263744)), shape = RoundedCornerShape(14.dp)) {
                        Text("▶  PLAY", fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    }
                    OutlinedButton(onClick = {
                        webView?.evaluateJavascript("pauseVideo();", null)
                        playbackState = "PAUSED"
                    }, enabled = videoLoaded, modifier = Modifier.weight(1f).height(54.dp), shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Cyan), colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)) {
                        Text("Ⅱ  PAUSE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    OutlinedButton(onClick = {
                        webView?.evaluateJavascript("stopVideo();", null)
                        playbackState = "STOPPED"
                    }, enabled = videoLoaded, modifier = Modifier.weight(1f).height(54.dp), shape = RoundedCornerShape(14.dp), border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF526273)), colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)) {
                        Text("■  STOP", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
                Text("Playback never resumes automatically. Screen off or app switching pauses the player.", color = Muted, fontSize = 10.sp, lineHeight = 15.sp)
            }
        }
    }

    private fun createPlayerWebView(context: Context): WebView {
        return WebView(context).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = true
            settings.allowFileAccess = false
            settings.allowContentAccess = false
            settings.javaScriptCanOpenWindowsAutomatically = false
            settings.setSupportMultipleWindows(false)
            isFocusable = true
            isFocusableInTouchMode = true
            webChromeClient = WebChromeClient()
            val assetLoader = WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(context))
                .build()
            webViewClient = object : WebViewClient() {
                override fun shouldInterceptRequest(view: WebView, request: android.webkit.WebResourceRequest) =
                    assetLoader.shouldInterceptRequest(request.url)
                override fun onPageFinished(view: WebView, url: String) {
                    pageReady = true
                    pendingVideoId?.let { id -> view.evaluateJavascript("loadVideo('$id');", null) }
                }
            }
            addJavascriptInterface(object {
                @JavascriptInterface fun onPlayerState(state: String) {
                    runOnUiThread {
                        playbackState = when (state) {
                            "1" -> if (screenOff || !lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)) "PAUSED" else "PLAYING"
                            "2", "5", "-1" -> "PAUSED"
                            "0" -> "STOPPED"
                            "3" -> "READY"
                            "READY" -> "READY"
                            else -> if (state.startsWith("ERROR")) "ERROR" else playbackState
                        }
                        if (screenOff || !lifecycle.currentState.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED)) {
                            webView?.evaluateJavascript("pauseVideo();", null)
                        }
                    }
                }
            }, "PlayTriggerBridge")
            loadUrl("https://appassets.androidplatform.net/assets/player.html")
        }
    }

    private fun loadVideo(id: String) {
        pendingVideoId = id
        videoLoaded = true
        playbackState = "READY"
        if (pageReady) webView?.evaluateJavascript("loadVideo('$id');", null)
    }

    private fun extractVideoId(input: String): String? {
        val s = input.trim()
        val patterns = listOf(
            Regex("(?:youtube\\.com/watch\\?v=)([A-Za-z0-9_-]{11})"),
            Regex("(?:youtu\\.be/)([A-Za-z0-9_-]{11})"),
            Regex("(?:youtube\\.com/embed/)([A-Za-z0-9_-]{11})"),
            Regex("(?:youtube\\.com/shorts/)([A-Za-z0-9_-]{11})")
        )
        return patterns.firstNotNullOfOrNull { it.find(s)?.groupValues?.getOrNull(1) }
            ?: if (Regex("^[A-Za-z0-9_-]{11}$").matches(s)) s else null
    }

    @Composable
    private fun StatusPill(status: String) {
        val color = when (status) { "PLAYING" -> Color(0xFF39D98A); "SCREEN OFF", "ERROR" -> Color(0xFFFF6B6B); else -> Cyan }
        Row(Modifier.background(color.copy(alpha = .12f), RoundedCornerShape(50)).padding(horizontal = 10.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(6.dp).background(color, RoundedCornerShape(50)))
            Spacer(Modifier.width(6.dp))
            Text(status.uppercase(Locale.US), color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = .5.sp)
        }
    }
}
